from django.apps import AppConfig


class GoncordAuthConfig(AppConfig):
    name = 'goncord_auth'
